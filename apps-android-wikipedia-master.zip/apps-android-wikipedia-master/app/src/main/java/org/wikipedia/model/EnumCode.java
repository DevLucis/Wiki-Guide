package org.wikipedia.model;

public interface EnumCode {
    int code();
}
