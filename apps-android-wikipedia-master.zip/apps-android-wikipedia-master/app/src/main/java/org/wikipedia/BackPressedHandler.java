package org.wikipedia;

public interface BackPressedHandler {
    boolean onBackPressed();
}
